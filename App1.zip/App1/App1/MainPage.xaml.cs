﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page, INotifyPropertyChanged
    {
        private string fileToLaunch = @"Assets\StoreLogo.png";
        private string htmlFileToLaunch = @"Assets\test.html";
        private string pngText;
        private string htmlText;
        private IStorageFile pngFile;
        private IStorageFile htmlFile;

        public MainPage()
        {
            this.InitializeComponent();
            this.DataContext = this;
            this.Loaded += OnLoaded;
        }

        private async void OnLoaded(object sender, RoutedEventArgs e)
        {
            // THIS ONE WORKS!
            pngFile = await GetPngFileToLaunch();

            // THIS ONE DOES NOT WORK!
            htmlFile = await GetHtmlFileToLaunch();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public string PngText { get => this.pngText; set { this.pngText = value; OnPropertyChanged(); } }
        public string HtmlText { get => this.htmlText; set { this.htmlText = value; OnPropertyChanged(); } }

        private async Task<IStorageFile> GetPngFileToLaunch()
        {
            this.PngText = "Launch Png in Default App";

            // First, get the image file from the package's image directory.
            pngFile = await Windows.ApplicationModel.Package.Current.InstalledLocation.GetFileAsync(fileToLaunch);

            //Can't launch files directly from install folder so copy it over 
            //to temporary folder first
            return await pngFile.CopyAsync(ApplicationData.Current.TemporaryFolder, "filetolaunch.png", NameCollisionOption.ReplaceExisting);
        }

        private async Task<IStorageFile> GetHtmlFileToLaunch()
        {
            this.HtmlText = "Launch Html File in Default App";

            // First, get the image file from the package's image directory.
            var file = await Windows.ApplicationModel.Package.Current.InstalledLocation.GetFileAsync(htmlFileToLaunch);

            //Can't launch files directly from install folder so copy it over 
            //to temporary folder first
            return await file.CopyAsync(ApplicationData.Current.TemporaryFolder, "filetolaunch.html", NameCollisionOption.ReplaceExisting);
        }

        private async void PngButton_Click(object sender, RoutedEventArgs e)
        {
            // Launch the file.
            bool success = await Launcher.LaunchFileAsync(pngFile);
            if (success)
            {
                Debug.WriteLine("File launch succeeded.");
            }
            else
            {
                Debug.WriteLine("File launch failed.");
            }
        }

        private async void HtmlButton_Click(object sender, RoutedEventArgs e)
        {
            // Specify a picker (according to MSFT documentation)
            var launcherOptions = new LauncherOptions() { DisplayApplicationPicker = true };

            // Launch the file.
            bool success = await Launcher.LaunchFileAsync(htmlFile, launcherOptions);

            if (success)
            {
                Debug.WriteLine("File launch succeeded.");
            }
            else
            {
                Debug.WriteLine("File launch failed.");
            }
        }
    }
}
