#include "pch.h"
#include "dllwrapper.h"
#include <stdio.h>
#include <thread>

#ifndef DLLWRAPPER_CPP
#define DLLWRAPPER_CPP

wrapper _Instance;

void wrapper::SendManagedCode(int code, WPARAM wparam, LPARAM lparam)
{
	if (_codeHandler != NULL)
	{
		_codeHandler(code, wparam, lparam);
	}
}

void wrapper::SendManagedMessage(const char* message)
{
	if (_messageHandler != NULL)
	{
		char messageToSend[150];
		sprintf_s(messageToSend, "dllwrapper: %s", message);
		_messageHandler(messageToSend);
	}
}

void wrapper::Init(unsigned int threadId, MessageCallback messageHandler, CodeCallback codeHandler)
{
	SendManagedMessage("Init called");
	_threadId = threadId;
	_messageHandler = messageHandler;
	_codeHandler = codeHandler;
	SetFileMapping();
}

bool wrapper::Start()
{
	SendManagedMessage("BEGIN Start()");

	// Load library in which we'll be hooking our functions.
	HMODULE dll = LoadLibrary(L"inject.dll");
	if (dll == NULL) {
		char errorMessage[100];
		sprintf_s(errorMessage, "ERR-LoadLibrary failed! ErrorCode=%d", GetLastError());
		SendManagedMessage(errorMessage);
		return false;
	}
	SendManagedMessage("LoadLibrary passed!");

	// Get the address of the function inside the DLL.
	HOOKPROC cbtProcAddress = (HOOKPROC)GetProcAddress(dll, "CbtProcCallback");
	if (cbtProcAddress == NULL) {
		char errorMessage[100];
		sprintf_s(errorMessage, "ERR-GetProcAddress for CbtProcCallback failed! ErrorCode=%d", GetLastError());
		SendManagedMessage(errorMessage);
		return false;
	}
	SendManagedMessage("GetProcAddress for CbtProcCallback passed!");

	// Hook the function
	cbtProcHook = SetWindowsHookEx(WH_CBT, cbtProcAddress, dll, _threadId);
	if (cbtProcHook == NULL) {
		char errorMessage[100];
		sprintf_s(errorMessage, "ERR-SetWindowsHookEx cbtProcAddress failed! ErrorCode=%d", GetLastError());
		SendManagedMessage(errorMessage);
		return false;
	}
	SendManagedMessage("SetWindowsHookEx for cbtProcAddress passed!");

	// Get the address of the function inside the DLL.
	HOOKPROC callWndProcAddress = (HOOKPROC)GetProcAddress(dll, "CallWndProcCallback");
	if (callWndProcAddress == NULL) {
		char errorMessage[100];
		sprintf_s(errorMessage, "ERR-GetProcAddress for CallWndProcCallback failed! ErrorCode=%d", GetLastError());
		SendManagedMessage(errorMessage);
		return false;
	}
	SendManagedMessage("GetProcAddress for CallWndProcCallback passed!");

	// Hook the function
	callWndProcHook = SetWindowsHookEx(WH_CALLWNDPROC, callWndProcAddress, dll, _threadId);
	if (callWndProcHook == NULL) {
		char errorMessage[100];
		sprintf_s(errorMessage, "ERR-SetWindowsHookEx callWndProcAddress failed! ErrorCode=%d", GetLastError());
		SendManagedMessage(errorMessage);
		return false;
	}
	SendManagedMessage("SetWindowsHookEx for callWndProcAddress passed!");

	return true;
}

void wrapper::Stop()
{
	SendManagedMessage("BEGIN Stop()");
	if (cbtProcHook != NULL)
	{
		if (UnhookWindowsHookEx(cbtProcHook))
		{
			SendManagedMessage("UnhookWindowsHookEx cbtProcHook completed successfully.");
		}
		else
		{
			SendManagedMessage("ERR-UnhookWindowsHookEx cbtProcHook failed!");
		}
	}

	if (callWndProcHook != NULL)
	{
		if (UnhookWindowsHookEx(callWndProcHook))
		{
			SendManagedMessage("UnhookWindowsHookEx callWndProcHook completed successfully.");
		}
		else
		{
			SendManagedMessage("ERR-UnhookWindowsHookEx callWndProcHook failed!");
		}
	}

	DestroyFileMapping();
	SendManagedMessage("END Stop()");
}

void SetFileMapping()
{
	_hmapFile = CreateFileMapping(
		INVALID_HANDLE_VALUE,
		NULL,
		PAGE_READWRITE,
		0,
		BUF_SIZE,
		L"hsbmapping");
	if (_hmapFile == NULL)
	{
		return;
	}

	_payload = (MYHOOKDATA*)MapViewOfFile(_hmapFile, FILE_MAP_WRITE | FILE_MAP_READ, 0, 0, BUF_SIZE);
	_event = CreateEvent(NULL, false, false, L"hsbevent");
	// Start a Thread and wait for the event
	_active = true;
	_threadHandle = CreateThread(NULL, 0, MyThreadFunction, NULL, 0, &_threadId);
}

void DestroyFileMapping()
{

	// Terminate the threads
	_active = true;
	if (SetEvent(_event) == false)
	{
		_Instance.SendManagedMessage("ERR-failed to set event from StopHooks!");
	}
	WaitForSingleObject(_threadHandle, 200);
	if (CloseHandle(_threadHandle) == false)
	{
		_Instance.SendManagedMessage("ERR-Unable to close handle: _threadHandle");

	}

	if (_payload != 0)
	{
		if (!UnmapViewOfFile(_payload))
		{
			_Instance.SendManagedMessage("ERR-UnmapViewOfFile failed!");
		}
	}

	if (_event != 0)
	{
		if (!CloseHandle(_event))
		{
			_Instance.SendManagedMessage("ERR-CloseHandle(_event) failed!");
		}
	}

	if (_hmapFile != 0)
	{
		if (!CloseHandle(_hmapFile))
		{
			_Instance.SendManagedMessage("ERR-CloseHandle(_hmapFile) failed!");
		}
	}
}

DWORD WINAPI MyThreadFunction(LPVOID lpParam)
{
	while (_active)
	{
		// Wait for the event
		WaitForSingleObject(_event, INFINITE);

		// Read the buffer for its content.  If the payload code is -1, then that means you wish to terminate this thread.
		if (_active == false)
		{
			_Instance.SendManagedMessage("Terminating event thread.");
			if (CloseHandle(_event) == false)
			{
				_Instance.SendManagedMessage("ERR-Unable to close handle: _event");

			}
		}
		else
		{
			// Send the buffer info to your delegate
			_Instance.SendManagedCode(_payload->code, _payload->wparam, _payload->lparam);
		}
	}

	return 0;
}

bool StartHooks(unsigned int threadId, MessageCallback messageHandler, CodeCallback codeHandler)
{
	_Instance.Init(threadId, messageHandler, codeHandler);
	return _Instance.Start();
}

void StopHooks()
{
	_Instance.Stop();
}

#endif