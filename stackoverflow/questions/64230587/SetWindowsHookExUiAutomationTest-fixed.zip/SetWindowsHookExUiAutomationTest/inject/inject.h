#ifndef INJECT_H
#define INJECT_H
extern "C" __declspec(dllexport) LRESULT CALLBACK CbtProcCallback(int code, WPARAM wparam, LPARAM lparam);
extern "C" __declspec(dllexport) LRESULT CALLBACK CallWndProcCallback(int code, WPARAM wparam, LPARAM lparam);
typedef struct _MYHOOKDATA
{
    int code;
    WPARAM wparam;
    LPARAM lparam;
} MYHOOKDATA;

#define BUF_SIZE 256
HANDLE _hmapFile;
HANDLE _event;
MYHOOKDATA* _payload;
void SetFileMapping();
void DestroyFileMapping();
void SendPayload(int code, WPARAM wparam, LPARAM lparam);
#endif