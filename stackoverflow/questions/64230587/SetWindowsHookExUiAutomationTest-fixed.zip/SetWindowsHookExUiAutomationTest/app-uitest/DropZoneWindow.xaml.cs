﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace app_uitest
{
    /// <summary>
    /// Interaction logic for DropZoneWindow.xaml
    /// </summary>
    public partial class DropZoneWindow : Window, INotifyPropertyChanged
    {
        private Rect rectLocation1;
        private Rect rectLocation2;
        private bool rect1Activated;
        private bool rect2Activated;
        private double scaleFactor = 1;

        public event PropertyChangedEventHandler PropertyChanged;
        public bool Rect1Activated { get => this.rect1Activated; set { this.rect1Activated = value; OnPropertyChanged(); } }
        public bool Rect2Activated { get => this.rect2Activated; set { this.rect2Activated = value; OnPropertyChanged(); } }

        public void OnPropertyChanged([CallerMemberName] string memberName = null)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(memberName));
        }

        public DropZoneWindow()
        {
            InitializeComponent();
            this.IsVisibleChanged += DropZoneWindow_IsVisibleChanged;
            this.Loaded += DropZoneWindow_Loaded;
            this.PropertyChanged += DropZoneWindow_PropertyChanged;
        }

        private void DropZoneWindow_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(this.Rect1Activated))
            {
                if (this.Rect1Activated)
                {
                    ColorChange(rect1, Colors.Yellow);
                }
                else
                {
                    ColorChange(rect1, Colors.Blue);
                }
            }
            else if (e.PropertyName == nameof(this.Rect2Activated))
            {
                if (this.Rect2Activated)
                {
                    ColorChange(rect2, Colors.Yellow);
                }
                else
                {
                    ColorChange(rect2, Colors.Blue);
                }
            }
        }

        private void ColorChange(Rectangle rect2, Color colorToSet)
        {
            rect2.Fill = new SolidColorBrush(colorToSet);
        }

        private void DropZoneWindow_Loaded(object sender, RoutedEventArgs e)
        {
            MainWindowViewModel.WriteInfo("DropZoneWindow is loaded.");
            var rect1Point = rect1.PointToScreen(new Point(0, 0));
            rectLocation1 = new Rect(rect1Point, new Size(rect1.ActualWidth, rect2.ActualHeight));
            var rect2Point = rect2.PointToScreen(new Point(0, 0));
            rectLocation2 = new Rect(rect2Point, new Size(rect2.ActualWidth, rect2.ActualHeight));
            if (Visibility == Visibility.Visible)
            {
                MainWindowViewModel.WriteInfo("DropZoneWindow is visible.");
                Task.Run(() => MonitorMousePosition());
            }
            else
            {
                MainWindowViewModel.WriteInfo("DropZoneWindow is hidden.");
            }

            GetScaleFactor();
        }

        private void GetScaleFactor()
        {
            PresentationSource source = PresentationSource.FromVisual(this);

            double dpiX, dpiY;
            if (source != null)
            {
                dpiX = 96.0 * source.CompositionTarget.TransformToDevice.M11;
                dpiY = 96.0 * source.CompositionTarget.TransformToDevice.M22;
                this.scaleFactor = dpiX / 96.0;
            }
        }

        private void DropZoneWindow_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            MainWindowViewModel.WriteInfo($"IsVisible changed: {Visibility}");
            if (this.IsLoaded)
            {
                if (Visibility == Visibility.Visible)
                {
                    MainWindowViewModel.WriteInfo("DropZoneWindow is visible.");
                    Task.Run(() => MonitorMousePosition());
                }
                else
                {
                    MainWindowViewModel.WriteInfo("DropZoneWindow is hidden.");
                }
            }
        }


        public System.Windows.Point GetMousePosition()
        {
            var point = System.Windows.Forms.Control.MousePosition;
            return new Point(point.X * this.scaleFactor, point.Y * this.scaleFactor);
        }

        private async Task MonitorMousePosition()
        {
            try
            {
                var lastMouse = new Point(0, 0);
                while (Visibility == Visibility.Visible)
                {
                    Matrix transform = new Matrix();
                    Point mouse = new Point(0, 0);
                    // Keep getting the current mouse position
                    this.Dispatcher.Invoke((Action)(() =>
                    {
                        transform = PresentationSource.FromVisual(this).CompositionTarget.TransformFromDevice;
                        mouse = transform.Transform(GetMousePosition());
                        // Check to see if you are either over rect1 or rect2
                        if (rectLocation1.Contains(mouse))
                        {
                            if (!this.Rect1Activated)
                                this.Rect1Activated = true;
                        }
                        else
                        {
                            if (this.Rect1Activated)
                                this.Rect1Activated = false;
                        }
                        if (rectLocation2.Contains(mouse))
                        {
                            if (!this.Rect2Activated)
                                this.Rect2Activated = true;
                        }
                        else
                        {
                            if (this.Rect2Activated)
                                this.Rect2Activated = false;
                        }
                        if (mouse.X != lastMouse.X || mouse.Y != lastMouse.Y)
                        {
                            //MainWindowViewModel.WriteInfo($"{mouse},{rectLocation1}");
                            lastMouse = mouse;
                        }
                    }));
                    await Task.Delay(25);
                }
            }
            catch (TaskCanceledException)
            {

            }
        }
    }
}
