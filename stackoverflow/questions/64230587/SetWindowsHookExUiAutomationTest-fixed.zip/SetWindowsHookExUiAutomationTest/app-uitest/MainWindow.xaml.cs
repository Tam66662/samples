﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace app_uitest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Timer timer;
        private DropZoneWindow dropZoneWindow;
        public MainWindowViewModel ViewModel { get; private set; }

        public MainWindow()
        {
            InitializeComponent();
            this.dropZoneWindow = new DropZoneWindow();
            this.ViewModel = new MainWindowViewModel(this.Dispatcher);
            this.ViewModel.PropertyChanged += OnViewModelPropertyChanged;
            this.DataContext = this.ViewModel;
            this.dropZoneWindow.DataContext = this.DataContext;
            this.Loaded += OnLoaded;
            this.Closing += OnClosing;
            this.Closed += OnClosed;
        }

        private void OnViewModelPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(this.ViewModel.Moving))
            {
                if (this.ViewModel.Moving)
                {
                    this.dropZoneWindow.Show();
                }
                else
                {
                    this.dropZoneWindow.Hide();
                }
            }
        }

        private void OnClosed(object sender, EventArgs e)
        {
            MainWindowViewModel.WriteInfo("MainWindow closed.");
        }

        private void OnClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                MainWindowViewModel.WriteInfo("MainWindow closing.");
                if (this.timer != null)
                {
                    this.timer.Dispose();
                    this.timer = null;
                    MainWindowViewModel.WriteInfo("timer is disposed.");
                }
                if (this.ViewModel != null)
                {
                    this.ViewModel.Dispose();
                    this.ViewModel = null;
                    MainWindowViewModel.WriteInfo("ViewModel is disposed.");
                }
                if (this.dropZoneWindow != null)
                {
                    this.dropZoneWindow.Close();
                    MainWindowViewModel.WriteInfo("dropZoneWindow closed.");
                }
            }
            catch (Exception ex)
            {
                MainWindowViewModel.WriteInfo($"{ex.GetType()}: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            try
            {
                MainWindowViewModel.WriteInfo("MainWindow loaded.");
                this.timer = new Timer(TimerCallbackMethod, null, 5000, 5000);
                Task.Run(() => this.ViewModel.Initialize());
            }
            catch (Exception ex)
            {
                MainWindowViewModel.WriteInfo($"{ex.GetType()}: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private void TimerCallbackMethod(object state)
        {
            try
            {
                this.Dispatcher.BeginInvoke((Action)(() =>
                {
                    this.textBox.ScrollToEnd();
                }), null);
            }
            catch (Exception ex)
            {
                MainWindowViewModel.WriteInfo($"{ex.GetType()}: {ex.Message}\n{ex.StackTrace}");
            }
        }
    }
}
