#include "pch.h"
#include "inject.h"

void Init(MYFUNCPTR funcPtr)
{
	_handler = funcPtr;
}

LRESULT CALLBACK CbtProcCallback(int code, WPARAM wparam, LPARAM lparam)
{
	if (code >= 0)
	{
		// Only send the code if you are about to MAXIMIZE
		if (code == HCBT_MINMAX)
		{
			if (lparam == SW_MAXIMIZE)
			{
				_handler(0, wparam, lparam);
			}
		}
	}

	return CallNextHookEx(NULL, code, wparam, lparam);
}

LRESULT CALLBACK CallWndProcCallback(int code, WPARAM wparam, LPARAM lparam)
{
	if (code >= 0)
	{
		if (code == HC_ACTION)
		{
			// LPARAM contains a pointer to a CWPSTRUCT that contains details about the message
			CWPSTRUCT* message = (CWPSTRUCT*)lparam;
			if (message->message == WM_MOVING)
			{
				_handler(1, wparam, lparam);
			}
			else if (message->message == WM_EXITSIZEMOVE)
			{
				_handler(2, wparam, lparam);
			}
		}
	}

	return CallNextHookEx(NULL, code, wparam, lparam);
}

