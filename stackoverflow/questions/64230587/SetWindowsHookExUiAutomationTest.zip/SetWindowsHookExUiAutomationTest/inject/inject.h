#pragma once
#ifndef INJECT_H
#define INJECT_H
typedef void(__stdcall* MYFUNCPTR)(int code, WPARAM wparam, LPARAM lparam);
extern "C" __declspec(dllexport) void Init(MYFUNCPTR funcPtr);
extern "C" __declspec(dllexport) LRESULT CALLBACK CbtProcCallback(int code, WPARAM wparam, LPARAM lparam);
extern "C" __declspec(dllexport) LRESULT CALLBACK CallWndProcCallback(int code, WPARAM wparam, LPARAM lparam);
MYFUNCPTR _handler = 0;
#endif