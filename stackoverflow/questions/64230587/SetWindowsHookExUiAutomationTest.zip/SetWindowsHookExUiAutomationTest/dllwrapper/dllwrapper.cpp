#include "pch.h"
#include "dllwrapper.h"
#include <stdio.h>

#ifndef DLLWRAPPER_CPP
#define DLLWRAPPER_CPP

void wrapper::SendManagedCode(int code, WPARAM wparam, LPARAM lparam)
{
	if (_codeHandler != NULL)
	{
		_codeHandler(code, wparam, lparam);
	}
}

void wrapper::SendManagedMessage(const char* message)
{
	if (_messageHandler != NULL)
	{
		char messageToSend[150];
		sprintf_s(messageToSend, "dllwrapper: %s", message);
		_messageHandler(messageToSend);
	}
}

void wrapper::Init(unsigned int threadId, MessageCallback messageHandler, CodeCallback codeHandler)
{
	_threadId = threadId;
	_messageHandler = messageHandler;
	_codeHandler = codeHandler;
	SendManagedMessage("Init called");
}

bool wrapper::Start()
{
	SendManagedMessage("BEGIN Start()");

	// Load library in which we'll be hooking our functions.
	HMODULE dll = LoadLibrary(L"inject.dll");
	if (dll == NULL) {
		char errorMessage[100];
		sprintf_s(errorMessage, "ERR-LoadLibrary failed! ErrorCode=%d", GetLastError());
		SendManagedMessage(errorMessage);
		return false;
	}
	SendManagedMessage("LoadLibrary passed!");

	// Get the address of the function inside the DLL.
	MYPROC iaddr = (MYPROC)GetProcAddress(dll, "Init");
	if (iaddr == NULL) {
		char errorMessage[100];
		sprintf_s(errorMessage, "ERR-GetProcAddress for Init failed! ErrorCode=%d", GetLastError());
		SendManagedMessage(errorMessage);
		return false;
	}
	SendManagedMessage("GetProcAddress for Init passed!");
	iaddr(OnInjectionCallback);

	// Get the address of the function inside the DLL.
	HOOKPROC cbtProcAddress = (HOOKPROC)GetProcAddress(dll, "CbtProcCallback");
	if (cbtProcAddress == NULL) {
		char errorMessage[100];
		sprintf_s(errorMessage, "ERR-GetProcAddress for CbtProcCallback failed! ErrorCode=%d", GetLastError());
		SendManagedMessage(errorMessage);
		return false;
	}
	SendManagedMessage("GetProcAddress for CbtProcCallback passed!");

	// Hook the function
	cbtProcHook = SetWindowsHookEx(WH_CBT, cbtProcAddress, dll, _threadId);
	if (cbtProcHook == NULL) {
		char errorMessage[100];
		sprintf_s(errorMessage, "ERR-SetWindowsHookEx cbtProcAddress failed! ErrorCode=%d", GetLastError());
		SendManagedMessage(errorMessage);
		return false;
	}
	SendManagedMessage("SetWindowsHookEx for cbtProcAddress passed!");

	//// Get the address of the function inside the DLL.
	//HOOKPROC callWndProcAddress = (HOOKPROC)GetProcAddress(dll, "CallWndProcCallback");
	//if (callWndProcAddress == NULL) {
	//	char errorMessage[100];
	//	sprintf_s(errorMessage, "ERR-GetProcAddress for CallWndProcCallback failed! ErrorCode=%d", GetLastError());
	//	SendManagedMessage(errorMessage);
	//	return false;
	//}
	//SendManagedMessage("GetProcAddress for CallWndProcCallback passed!");

	//// Hook the function
	//callWndProcHook = SetWindowsHookEx(WH_CALLWNDPROC, callWndProcAddress, dll, _threadId);
	//if (callWndProcHook == NULL) {
	//	char errorMessage[100];
	//	sprintf_s(errorMessage, "ERR-SetWindowsHookEx callWndProcAddress failed! ErrorCode=%d", GetLastError());
	//	SendManagedMessage(errorMessage);
	//	return false;
	//}
	//SendManagedMessage("SetWindowsHookEx for callWndProcAddress passed!");

	return true;
}

void wrapper::Stop()
{
	SendManagedMessage("BEGIN Stop()");
	if (cbtProcHook != NULL)
	{
		if (UnhookWindowsHookEx(cbtProcHook))
		{
			SendManagedMessage("UnhookWindowsHookEx cbtProcHook completed successfully.");
		}
		else
		{
			SendManagedMessage("ERR-UnhookWindowsHookEx cbtProcHook failed!");
		}
	}

	if (callWndProcHook != NULL)
	{
		if (UnhookWindowsHookEx(callWndProcHook))
		{
			SendManagedMessage("UnhookWindowsHookEx callWndProcHook completed successfully.");
		}
		else
		{
			SendManagedMessage("ERR-UnhookWindowsHookEx callWndProcHook failed!");
		}
	}
	SendManagedMessage("END Stop()");
}

#endif