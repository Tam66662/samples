// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"
#include "dllwrapper.h"
#include <stdio.h>

BOOL APIENTRY DllMain( HMODULE hInst,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

wrapper _Instance;

bool StartHooks(unsigned int threadId, MessageCallback messageHandler, CodeCallback codeHandler)
{
    _Instance.Init(threadId, messageHandler, codeHandler);
    return _Instance.Start();
}

void StopHooks()
{
    _Instance.Stop();
}

void OnInjectionCallback(int code, WPARAM wparam, LPARAM lparam)
{
    _Instance.SendManagedCode(code, wparam, lparam);
}

