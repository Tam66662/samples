#pragma once
#ifndef DLLWRAPPER_H
#define DLLWRAPPER_H

typedef void(__stdcall* CodeCallback)(int code, WPARAM wparam, LPARAM lparam);
typedef void(__stdcall* MessageCallback)(const char* message);
typedef void(__stdcall* MYPROC)(void(*)(int code, WPARAM wparam, LPARAM lparam));
void OnInjectionCallback(int code, WPARAM wparam, LPARAM lparam);
static HHOOK cbtProcHook = NULL;
static HHOOK callWndProcHook = NULL;

#ifdef __cplusplus
extern "C" {  // only need to export C interface if
			  // used by C++ source code
#endif

	__declspec(dllexport) bool StartHooks(unsigned int threadId, MessageCallback messageCallback, CodeCallback codeCallback);
	__declspec(dllexport) void StopHooks();

#ifdef __cplusplus
}
#endif


class wrapper {
private:
	CodeCallback _codeHandler;
	MessageCallback _messageHandler;
	unsigned int _threadId;
public:
	void Init(unsigned int threadId, MessageCallback messageHandler, CodeCallback codeHandler);
	bool Start();
	void Stop();
	void SendManagedCode(int code, WPARAM wparam, LPARAM lparam);
	void SendManagedMessage(const char* message);
};

#endif