﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Automation;
using System.Windows.Threading;

namespace app_uitest
{
    public class MainWindowViewModel : ViewModelBase, IDisposable
    {
        private string output;
        private LogManagerListener listener;
        private NativeMethods.MessageCallback messageCallback;
        private NativeMethods.CodeCallback codeCallback;
        private bool moving;
        private static object lockObject = new object();
        private IntPtr savedHwnd = IntPtr.Zero;
        private Dispatcher dispatcher;
        static AutomationElement _lastWindow;

        public static void WriteInfo(string message)
        {
            var datetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff | ");
            Trace.WriteLine($"{datetime} {message}");
        }

        public MainWindowViewModel(Dispatcher dispatcher)
        {
            try
            {
                this.dispatcher = dispatcher;
                listener = new LogManagerListener(this);
                messageCallback = new NativeMethods.MessageCallback(MessageCallback);
                codeCallback = new NativeMethods.CodeCallback(CodeCallback);
                Trace.Listeners.Add(listener);
                this.PropertyChanged += OnViewModelPropertyChanged;
            }
            catch (Exception ex)
            {
                MainWindowViewModel.WriteInfo($"{ex.GetType()}: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private static AutomationElement GetParentWindow(AutomationElement element)
        {
            AutomationElement node = element;
            try
            {
                while (!Equals(node.Current.ControlType, ControlType.Window))
                {
                    node = TreeWalker.ControlViewWalker.GetParent(node);
                    if (node == null)
                        return null;
                }

                return node;
            }
            catch (ElementNotAvailableException)
            {
            }

            return null;
        }

        // see https://msdn.microsoft.com/en-us/library/windows/desktop/ms684139%28v=vs.85%29.aspx
        public static bool Is64Bit(Process process)
        {
            if (!Environment.Is64BitOperatingSystem)
                return false;
            // if this method is not available in your version of .NET, use GetNativeSystemInfo via P/Invoke instead

            bool isWow64;
            if (!NativeMethods.IsWow64Process(process.Handle, out isWow64))
                throw new Win32Exception();
            return !isWow64;
        }

        private void OnFocusChanged(object sender, AutomationFocusChangedEventArgs e)
        {
            lock (lockObject)
            {
                AutomationElement element = sender as AutomationElement;
                if (element == null) return;

                try
                {
                    AutomationElement topLevelWindow = GetParentWindow(element);
                    if (topLevelWindow == null)
                        return;

                    if (topLevelWindow != _lastWindow)
                    {
                        _lastWindow = topLevelWindow;
                        MainWindowViewModel.WriteInfo($"Focus moved to window: {topLevelWindow.Current.Name}");
                    }

                    // Ignore certain elements, such as devenv.exe for debugging
                    using (var p = Process.GetProcessById(element.Current.ProcessId))
                    {
                        var bitProcess = Is64Bit(p) ? "64-bit" : "32-bit";
                        var focusedHwnd = p.MainWindowHandle;

                        // Ignore procexp64.exe
                        if (p.ProcessName.Contains("procexp64")) return;

                        if (focusedHwnd != IntPtr.Zero && focusedHwnd != savedHwnd)
                        {
                            StopListeningToApps();
                            MainWindowViewModel.WriteInfo($"Compare:{focusedHwnd},{savedHwnd}");
                            savedHwnd = focusedHwnd;
                            MainWindowViewModel.WriteInfo($"Window Focused: {p.Id},{p.MainWindowHandle},{p.ProcessName} ({bitProcess})");
                            var threadId = NativeMethods.GetWindowThreadProcessId(p.MainWindowHandle, out uint processId);
                            StartListeningToApps(threadId);
                        }
                        else
                        {
                            // Debounce when window is the same as the currently tracked foreground app window
                        }
                    }
                }
                catch (ElementNotAvailableException ex)
                {
                    MainWindowViewModel.WriteInfo($"{ex.GetType()}: {ex.Message}\n{ex.StackTrace}");
                }
                catch (Exception ex)
                {
                    MainWindowViewModel.WriteInfo($"{ex.GetType()}: {ex.Message}\n{ex.StackTrace}");
                }
            }
        }

        private void StopListeningToApps()
        {
            try
            {
                NativeMethods.StopHooks();
                MainWindowViewModel.WriteInfo("Hook stopped.");
            }
            catch (Exception ex)
            { 
                MainWindowViewModel.WriteInfo($"{ex.GetType()} {ex.Message}\nWin32Error: {Marshal.GetLastWin32Error()}");
            }
        }

        private bool StartListeningToApps(uint threadId)
        {
            try
            {
                if (NativeMethods.StartHooks(threadId, messageCallback, codeCallback))
                {
                    MainWindowViewModel.WriteInfo($"Hook started.");
                    return true;
                }
                else
                {
                    MainWindowViewModel.WriteInfo($"ERR-Hook failed to start!");
                    return false;
                }
            }
            catch (Exception ex)
            {
                MainWindowViewModel.WriteInfo($"{ex.GetType()} {ex.Message}\nWin32Error: {Marshal.GetLastWin32Error()}");
                return false;
            }
        }

        private void OnViewModelPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(this.Moving))
            {
                MainWindowViewModel.WriteInfo($"{e.PropertyName} = {this.Moving} ({savedHwnd})");
                // Get the window's current position
                var threadId = NativeMethods.GetWindowThreadProcessId(savedHwnd, out uint processId);
                NativeMethods.GetWindowRect(savedHwnd, out NativeMethods.RECT lpRect);
                var rect = new Rectangle(lpRect.Left, lpRect.Top, lpRect.Right - lpRect.Left, lpRect.Bottom - lpRect.Top);
                if (this.Moving)
                {
                    MainWindowViewModel.WriteInfo($"Window Started Moving: {rect}");
                }
                else
                {
                    MainWindowViewModel.WriteInfo($"Window Stopped Moving: {rect}");                    
                }
            }
        }

        public string Output { get => this.output; set { this.output = value; OnPropertyChanged(); } }
        public string MyTitle { get => "Hook Test"; }
        public bool Moving { get => this.moving; set { this.moving = value; OnPropertyChanged(); } }
        public void Dispose()
        {
            try
            {
                if (listener != null)
                {
                    Trace.Listeners.Remove(listener);
                    listener.Dispose();
                    listener = null;
                    MainWindowViewModel.WriteInfo("listener disposed.");
                }
            }
            catch (Exception ex)
            {
                MainWindowViewModel.WriteInfo($"{ex.GetType()}: {ex.Message}\n{ex.StackTrace}");
            }
            finally
            {
                StopListeningToApps();
                Automation.RemoveAllEventHandlers();
            }
        }

        public void Initialize()
        {
            try
            {
                _lastWindow = AutomationElement.FromHandle(Process.GetCurrentProcess().MainWindowHandle);
                var threadId = NativeMethods.GetWindowThreadProcessId(Process.GetCurrentProcess().MainWindowHandle, out uint processId);
                if (StartListeningToApps(threadId))
                {
                    Automation.AddAutomationFocusChangedEventHandler(OnFocusChanged);
                }
                else
                {
                    MainWindowViewModel.WriteInfo("ERR-Failed to initialize!");
                }
            }
            catch (Exception ex)
            {
                MainWindowViewModel.WriteInfo($"{ex.GetType()}: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private void MessageCallback(string message)
        {
            MainWindowViewModel.WriteInfo($"{message}");
        }

        private void CodeCallback(int code, IntPtr wParam, IntPtr lParam)
        {
            this.dispatcher.Invoke((Action)(() => 
            {
                // MIN MAX code
                if (code == 0)
                {
                    MainWindowViewModel.WriteInfo($"Code:{(NativeMethods.HCBTMessage)code},Inner:{(NativeMethods.SHOW_WINDOW)lParam}");
                }
                // WM_MOVING code
                else if (code == 1)
                {
                    if (!this.Moving)
                    {
                        this.Moving = true;
                    }
                }
                // WM_EXITSIZEMOVE code
                else if (code == 2)
                {
                    if (this.Moving) this.Moving = false;
                }
                else
                {
                    MainWindowViewModel.WriteInfo($"Code:{(NativeMethods.HCBTMessage)code},Inner:{lParam}");
                }
            }));
        }
    }
}
