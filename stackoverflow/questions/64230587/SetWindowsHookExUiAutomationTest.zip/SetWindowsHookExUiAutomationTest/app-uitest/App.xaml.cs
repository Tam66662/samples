﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Windows;

namespace app_uitest
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            //LogManager.Initialize(LogLevel.Verbose, SynchronizationContext.Current, @"c:\tmp");
            var view = new MainWindow();
            view.Show();
            this.DispatcherUnhandledException += App_DispatcherUnhandledException;
        }

        private void App_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            MainWindowViewModel.WriteInfo($"{e.Exception.GetType()}: {e.Exception.Message}\n{e.Exception.StackTrace}");
        }
    }
}
