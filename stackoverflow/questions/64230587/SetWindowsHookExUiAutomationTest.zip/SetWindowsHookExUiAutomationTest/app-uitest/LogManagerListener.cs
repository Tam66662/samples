﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace app_uitest
{
    public class LogManagerListener : TraceListener
    {
        public MainWindowViewModel Parent { get; private set; }
        public LogManagerListener(MainWindowViewModel parent)
        {
            this.Parent = parent;
        }

        public override void Write(string message)
        {
            this.Parent.Output += $"{message}";
        }

        public override void WriteLine(string message)
        {
            this.Parent.Output += $"{message}\n";
        }
    }
}
