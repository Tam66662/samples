﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OverlayAnimationTest
{
    /// <summary>
    /// Interaction logic for OverlayWindow.xaml
    /// </summary>
    public partial class OverlayWindow : Window
    {
        private Storyboard showStoryboard;
        private Storyboard hideStoryboard;
        public OverlayWindow()
        {
            InitializeComponent();
            this.IsVisibleChanged += OverlayWindow_IsVisibleChanged;
            this.Loaded += OverlayWindow_Loaded;
            InitAnimations();
        }

        private void OverlayWindow_Loaded(object sender, RoutedEventArgs e)
        {
            showStoryboard.Begin(this.mainGrid, false);
        }

        private void OverlayWindow_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (this.Visibility == Visibility.Visible)
            {
                showStoryboard.Begin(this.mainGrid, false);
            }
            else
            {
                hideStoryboard.Begin(this.mainGrid, false);
            }
        }

        private void InitAnimations()
        {
            // When you have content to show, start an animation to display it.
            var opacityShowAnimation = new DoubleAnimation(0, 1, new Duration(TimeSpan.FromMilliseconds(500)), FillBehavior.HoldEnd);
            var scaleXShowAnimation = new DoubleAnimation(0.5, 1, new Duration(TimeSpan.FromMilliseconds(500)), FillBehavior.HoldEnd) { DecelerationRatio = 0.8 };
            var scaleYShowAnimation = new DoubleAnimation(0.5, 1, new Duration(TimeSpan.FromMilliseconds(500)), FillBehavior.HoldEnd) { DecelerationRatio = 0.8 };

            showStoryboard = new Storyboard();
            Storyboard.SetTargetName(scaleXShowAnimation, "scaleTransform");
            Storyboard.SetTargetName(scaleYShowAnimation, "scaleTransform");
            Storyboard.SetTargetProperty(scaleXShowAnimation, new PropertyPath("ScaleX"));
            Storyboard.SetTargetProperty(scaleYShowAnimation, new PropertyPath("ScaleY"));
            Storyboard.SetTargetProperty(opacityShowAnimation, new PropertyPath("Opacity"));

            showStoryboard.Children.Add(opacityShowAnimation);
            showStoryboard.Children.Add(scaleXShowAnimation);
            showStoryboard.Children.Add(scaleYShowAnimation);

            // When you have content to hide, start an animation to hide it.
            var opacityHideAnimation = new DoubleAnimation(1, 0, new Duration(TimeSpan.FromMilliseconds(500)), FillBehavior.HoldEnd);
            var scaleXHideAnimation = new DoubleAnimation(1, 0.5, new Duration(TimeSpan.FromMilliseconds(500)), FillBehavior.HoldEnd) { DecelerationRatio = 0.8 };
            var scaleYHideAnimation = new DoubleAnimation(1, 0.5, new Duration(TimeSpan.FromMilliseconds(500)), FillBehavior.HoldEnd) { DecelerationRatio = 0.8 };

            hideStoryboard = new Storyboard();
            Storyboard.SetTargetName(scaleXHideAnimation, "scaleTransform");
            Storyboard.SetTargetName(scaleYHideAnimation, "scaleTransform");
            Storyboard.SetTargetProperty(scaleXHideAnimation, new PropertyPath("ScaleX"));
            Storyboard.SetTargetProperty(scaleYHideAnimation, new PropertyPath("ScaleY"));
            Storyboard.SetTargetProperty(opacityHideAnimation, new PropertyPath("Opacity"));

            hideStoryboard.Children.Add(opacityHideAnimation);
            hideStoryboard.Children.Add(scaleXHideAnimation);
            hideStoryboard.Children.Add(scaleYHideAnimation);

        }
    }
}
