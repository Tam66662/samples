﻿using OverlayAnimationTest.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OverlayAnimationTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private OverlayWindow overlayWindow;

        public MainViewModel ViewModel
        {
            get
            {
                if (this.Dispatcher.CheckAccess())
                {
                    return this.DataContext as MainViewModel;
                }
                else
                {
                    return this.Dispatcher.Invoke(() => this.DataContext as MainViewModel);
                }
            }
        }

        public MainWindow()
        {
            InitializeComponent();
            this.MouseDown += MainWindow_MouseDown;
            this.MouseUp += MainWindow_MouseUp;
            this.overlayWindow = new OverlayWindow();
        }

        private void MainWindow_MouseUp(object sender, MouseButtonEventArgs e)
        {
            this.overlayWindow.Visibility = Visibility.Collapsed;
        }

        private void MainWindow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!this.overlayWindow.IsLoaded)
            {
                this.overlayWindow.Show();
            }
            else
            {
                this.overlayWindow.Visibility = Visibility.Visible;
            }
        }
    }
}
